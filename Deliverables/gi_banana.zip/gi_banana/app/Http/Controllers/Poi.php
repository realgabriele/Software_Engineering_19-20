<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Poi extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return \App\Poi::all();
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $poi = new \App\Poi();

        $poi->name = request( 'name' );
        $poi->description = request ( 'description' );

        $poi->x = request ( 'x' );
        $poi->y = request ( 'y' );

        $poi->save();

        return response(200);
    }

     /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return \App\Poi::find( $id );
    }

     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $toDelete = \App\Poi::find($id);
        if ( $toDelete )
            $toDelete->delete( );
            
        return response(200);
    }
}
