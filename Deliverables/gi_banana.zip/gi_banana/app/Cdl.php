<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cdl extends Model
{
    protected $table = "cdl";
}
