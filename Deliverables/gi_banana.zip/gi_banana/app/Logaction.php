<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Logaction extends Model
{
    protected $table = 'logaction';
}
