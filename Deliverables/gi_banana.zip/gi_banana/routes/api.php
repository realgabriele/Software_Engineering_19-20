<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/departments', 'Department@index');
Route::get('/departments/{id}', 'Department@show');
Route::post('/departments', 'Department@create');
Route::delete('/departments/{id}', 'Department@destroy');

Route::get('/cdl', 'Cdl@index');
Route::get('/cdl/{id}', 'Cdl@show');
Route::post('/cdl', 'Cdl@create');
Route::delete('/cdl/{id}', 'Cdl@destroy');

Route::get('/cdl', 'Cdl@index');
Route::get('/cdl/{id}', 'Cdl@show');
Route::post('/cdl', 'Cdl@create');
Route::delete('/cdl/{id}', 'Cdl@destroy');

Route::get('/poi', 'Poi@index');
Route::get('/poi/{id}', 'Poi@show');
Route::post('/poi', 'Poi@create');
Route::delete('/poi/{id}', 'Poi@destroy');

Route::get('/service', 'Service@index');
Route::get('/service/{id}', 'Service@show');
Route::post('/service', 'Service@create');
Route::delete('/service/{id}', 'Service@destroy');